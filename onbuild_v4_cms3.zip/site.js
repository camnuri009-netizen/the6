
const DEFAULT_DATA = {
  heroTitle:"공간을 새롭게 만들다\nONBUILD",
  heroText:"철거부터 원상복구, 인테리어까지<br>고객의 공간을 가치있게 변화시킵니다.",
  phone:"010-8476-9476",
  address:"경기도 남양주시 진접읍 부평로 36번길 8",
  images:{
    hero:"https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=1600",
    services:["https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=1200","https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=1200","https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=1200"],
    compare:["https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1200","https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=1200","https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=1200","https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=1200"],
    gallery:['https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=1200', 'https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=1200', 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=1200', 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1200', 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=1200', 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=1200', 'https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=1200', 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=1200', 'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?w=1200', 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200', 'https://images.unsplash.com/photo-1600573472591-ee6b68d14c68?w=1200', 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=1200', 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=1200', 'https://images.unsplash.com/photo-1600607687644-c7171b42498b?w=1200', 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=1200', 'https://images.unsplash.com/photo-1600210491892-03d54c0aaf87?w=1200', 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200', 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=1200', 'https://images.unsplash.com/photo-1600607688066-890987f18a86?w=1200', 'https://images.unsplash.com/photo-1600607688960-e095ff83135c?w=1200'],
    detail:[['https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=1200', 'https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=1200', 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=1200', 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1200', 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=1200', 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=1200', 'https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=1200', 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=1200', 'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?w=1200', 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200'],['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1200', 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=1200', 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=1200', 'https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=1200', 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=1200', 'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?w=1200', 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200', 'https://images.unsplash.com/photo-1600573472591-ee6b68d14c68?w=1200', 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=1200', 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=1200'],['https://images.unsplash.com/photo-1600573472591-ee6b68d14c68?w=1200', 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=1200', 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=1200', 'https://images.unsplash.com/photo-1600607687644-c7171b42498b?w=1200', 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=1200', 'https://images.unsplash.com/photo-1600210491892-03d54c0aaf87?w=1200', 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200', 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=1200', 'https://images.unsplash.com/photo-1600607688066-890987f18a86?w=1200', 'https://images.unsplash.com/photo-1600607688960-e095ff83135c?w=1200']]
  },
  services:[
    {icon:"🏗️",title:"철거",text:"상가 · 사무실 · 내부 철거<br>및 폐기물 정리"},
    {icon:"🔨",title:"원상복구",text:"임대 종료 후 천장 · 벽체 · 바닥<br>복구 및 정리"},
    {icon:"🎨",title:"인테리어",text:"상가 · 사무실 · 공간<br>리모델링"}
  ],
  galleryTitles:['01 철거 & 원상복구','02 철거 & 원상복구','03 철거 & 원상복구','04 철거 & 원상복구','05 철거 & 원상복구','06 철거 & 원상복구','07 철거 & 원상복구','08 철거 & 원상복구','09 철거 & 원상복구','10 철거 & 원상복구','11 인테리어','12 인테리어','13 인테리어','14 인테리어','15 인테리어','16 인테리어','17 인테리어','18 인테리어','19 인테리어','20 인테리어']
};
const STORE_KEY="onbuild_v4_data";
function getData(){return JSON.parse(localStorage.getItem(STORE_KEY)||"null")||structuredClone(DEFAULT_DATA)}
function setData(d){localStorage.setItem(STORE_KEY,JSON.stringify(d))}
let data=getData(); let gi=0,si=0,spi=0;
function renderSite(){
  if(document.getElementById("heroImg")) heroImg.src=data.images.hero;
  if(document.getElementById("heroTitle")) heroTitle.textContent=data.heroTitle;
  if(document.getElementById("heroText")) heroText.innerHTML=data.heroText;
  if(document.getElementById("servicesGrid")) servicesGrid.innerHTML=data.services.map((s,i)=>`<div class="serviceCard"><img src="${data.images.services[i]}"><div class="serviceBody"><div class="serviceIcon">${s.icon}</div><h3>${s.title}</h3><p>${s.text}</p><button class="more" onclick="openService(${i})">자세히 보기 →</button></div></div>`).join("");
  if(document.getElementById("compareFlow")) compareFlow.innerHTML=["시공 전","철거 진행","철거 완료","원상복구 완료"].map((t,i)=>`<div class="flowItem"><img src="${data.images.compare[i]}">${i<3?'<div class="arrowBadge">›</div>':''}<h4>${t}</h4><span>${['Before','Demolition','After Demolition','After Restoration'][i]}</span></div>`).join("");
  if(document.getElementById("galleryGrid")) galleryGrid.innerHTML=data.images.gallery.map((src,i)=>`<div class="galleryCard" onclick="openGallery(${i})"><div class="thumb"><img src="${src}"><span>${String(i+1).padStart(2,'0')}</span></div><p>${data.galleryTitles[i]||'시공사례'}</p></div>`).join("");
  document.querySelectorAll("[data-phone]").forEach(a=>a.href="tel:"+data.phone);
  document.querySelectorAll("[data-phone-text]").forEach(el=>el.textContent=data.phone);
  document.querySelectorAll("[data-address]").forEach(el=>el.textContent=data.address);
}
function openGallery(i){gi=i;renderGallery();imgModal.classList.add("show")}
function renderGallery(){modalImage.src=data.images.gallery[gi];modalTitle.textContent=data.galleryTitles[gi]||"시공사례";modalCount.textContent=(gi+1)+" / "+data.images.gallery.length}
function moveGallery(s){gi=(gi+s+data.images.gallery.length)%data.images.gallery.length;renderGallery()}
function hideGallery(){imgModal.classList.remove("show")}
function closeGallery(e){if(e.target.id==="imgModal")hideGallery()}
function openService(i){si=i;spi=0;renderService();serviceModal.classList.add("show")}
function renderService(){const arr=data.images.detail[si];serviceImage.src=arr[spi];serviceTitle.textContent=data.services[si].title+" 상세 이미지";serviceDesc.textContent=data.services[si].text.replace(/<br>/g," ");serviceCount.textContent=(spi+1)+" / "+arr.length;serviceThumbs.innerHTML=arr.map((src,i)=>`<img src="${src}" class="${i===spi?'active':''}" onclick="selectService(${i})">`).join("")}
function moveService(s){const arr=data.images.detail[si];spi=(spi+s+arr.length)%arr.length;renderService()}
function selectService(i){spi=i;renderService()}
function hideService(){serviceModal.classList.remove("show")}
function closeServiceModal(e){if(e.target.id==="serviceModal")hideService()}
document.addEventListener("keydown",e=>{if(e.key==="Escape"){if(window.imgModal)hideGallery();if(window.serviceModal)hideService();}if(window.imgModal&&imgModal.classList.contains("show")){if(e.key==="ArrowLeft")moveGallery(-1);if(e.key==="ArrowRight")moveGallery(1)}if(window.serviceModal&&serviceModal.classList.contains("show")){if(e.key==="ArrowLeft")moveService(-1);if(e.key==="ArrowRight")moveService(1)}});
document.addEventListener("DOMContentLoaded",renderSite);
